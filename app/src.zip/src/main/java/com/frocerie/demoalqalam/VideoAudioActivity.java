package com.frocerie.demoalqalam;

import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class VideoAudioActivity extends AppCompatActivity implements View.OnClickListener {


    ImageView ivLogo;

    Button video,audio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_audio);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ivLogo = (ImageView) findViewById(R.id.ivLogo);

        video = (Button) findViewById(R.id.btVideo);
        video.setOnClickListener(VideoAudioActivity.this);


        audio = (Button) findViewById(R.id.btAudio);
        audio.setOnClickListener(VideoAudioActivity.this);




    }

    @Override
    public void onClick(View view) {


        int id = view.getId();

        switch (id){


            case R.id.btVideo :


                Toast.makeText(VideoAudioActivity.this,"Connect to another  activity and get videos from server",Toast.LENGTH_SHORT).show();
                break;
            case R.id.btAudio :

                Toast.makeText(VideoAudioActivity.this,"Connect to another  activity and get Audios from server",Toast.LENGTH_SHORT).show();
                break;





        }



    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();



        if(id == R.id.home){

            NavUtils.navigateUpFromSameTask(VideoAudioActivity.this);

        }

        return super.onOptionsItemSelected(item);
    }
}
