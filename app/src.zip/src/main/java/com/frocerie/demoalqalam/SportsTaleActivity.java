package com.frocerie.demoalqalam;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.webkit.WebView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SportsTaleActivity extends AppCompatActivity {


    String url = "http://alqalamtrust.com/talentsday_toppers";


    String url_writing = "http://alqalamtrust.com/talentsday_toppers/Writing";


    //String url_sport = "http://alqalamtrust.com/talentsday_toppers/Speech";

    WebView webView;

    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sports_tale);



        webView = (WebView) findViewById(R.id.webViewSports);

        pdfSportsrequest();


    }

    private void pdfSportsrequest() {


        progressDialog  = new ProgressDialog(SportsTaleActivity.this);
        progressDialog.setMessage("Loding File.....");
        progressDialog.show();


        StringRequest stringRequest = new StringRequest(Request.Method.GET
                , url_writing, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                try {
                    JSONObject jsonObetct = new JSONObject(response);
                    JSONArray jsonArray = jsonObetct.getJSONArray("details");
                    JSONObject jsonObject1 = jsonArray.getJSONObject(0);

                    String pdfPath = jsonObject1.getString("pdf_path");

                    webView.getSettings().setJavaScriptEnabled(true);
                    webView.loadUrl("http://drive.google.com/viewerng/viewer?embedded=true&url="+pdfPath);




                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();





            }
        });


        RequestQueue rq = Volley.newRequestQueue(SportsTaleActivity.this);
        rq.add(stringRequest);





    }
}
