package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class ClothesActivityDua extends AppCompatActivity implements View.OnClickListener {


    TextView tvWear,tvRe,tvNew,tvPut;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clothes_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvWear = (TextView) findViewById(R.id.tvWear);
        tvWear.setOnClickListener(ClothesActivityDua.this);

        tvRe = (TextView) findViewById(R.id.tvRe);
        tvRe.setOnClickListener(ClothesActivityDua.this);

        tvNew = (TextView) findViewById(R.id.tvNew);
        tvNew.setOnClickListener(ClothesActivityDua.this);

        tvPut = (TextView) findViewById(R.id.tvPut);
        tvPut.setOnClickListener(ClothesActivityDua.this);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvWear :
                startActivity(new Intent(ClothesActivityDua.this,ClothesWeaActivity.class));
                break;

            case R.id.tvRe:
                startActivity(new Intent(ClothesActivityDua.this,ClothesRemActivity.class));
                break;

            case R.id.tvNew :

                startActivity(new Intent(ClothesActivityDua.this,ClothesNewActivity.class));
                break;

            case R.id.tvPut :

                startActivity(new Intent(ClothesActivityDua.this,ClothesPutActivity.class));
                break;




        }




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(ClothesActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }
}
