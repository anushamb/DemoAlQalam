package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class SalahActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView     tvSalWu,tvSalTa,tvSalAd,tvSal  ,tvSalRu ,tvSalQa, tvSalSu ,tvSalBe  ,tvSalTha,tvSalAft,tvSalMy;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salah_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tvSalWu = (TextView) findViewById(R.id.tvSalWu);
        tvSalWu.setOnClickListener(SalahActivityDua.this);


        tvSalTa = (TextView) findViewById(R.id.tvSalTa);
        tvSalTa.setOnClickListener(SalahActivityDua.this);


        tvSalAd = (TextView) findViewById(R.id.tvSalAd);
        tvSalAd.setOnClickListener(SalahActivityDua.this);

        tvSal = (TextView) findViewById(R.id.tvSal);
        tvSal.setOnClickListener(SalahActivityDua.this);

        tvSalRu = (TextView) findViewById(R.id.tvSalRu);
        tvSalRu.setOnClickListener(SalahActivityDua.this);

        tvSalQa = (TextView) findViewById(R.id.tvSalQa);
        tvSalQa.setOnClickListener(SalahActivityDua.this);

        tvSalSu = (TextView) findViewById(R.id.tvSalSu);
        tvSalSu.setOnClickListener(SalahActivityDua.this);

        tvSalBe = (TextView) findViewById(R.id.tvSalBe);
        tvSalBe.setOnClickListener(SalahActivityDua.this);

        tvSalTha = (TextView) findViewById(R.id.tvSalTha);
        tvSalTha.setOnClickListener(SalahActivityDua.this);

        tvSalAft = (TextView) findViewById(R.id.tvSalAft);
        tvSalAft.setOnClickListener(SalahActivityDua.this);

        tvSalMy = (TextView) findViewById(R.id.tvSalMy);
        tvSalMy.setOnClickListener(SalahActivityDua.this);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(SalahActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){



            case R.id.tvSalWu :

                startActivity(new Intent(SalahActivityDua.this,SalahWuduActivity.class));

                break;


            case R.id.tvSalTa :

                startActivity(new Intent(SalahActivityDua.this,SalahTayaActivity.class));

                break;



            case R.id.tvSalAd :

                startActivity(new Intent(SalahActivityDua.this,SalahAdhanActivity.class));

                break;



            case R.id. tvSal :

                startActivity(new Intent(SalahActivityDua.this,SalahSalActivity.class));

                break;



            case R.id.tvSalRu :

                startActivity(new Intent(SalahActivityDua.this,SalahRukuActivity.class));

                break;



            case R.id.tvSalQa :

                startActivity(new Intent(SalahActivityDua.this,SalahQaumActivity.class));

                break;



            case R.id.tvSalSu :

                startActivity(new Intent(SalahActivityDua.this,SalahSujoActivity.class));

                break;



            case R.id.tvSalBe :

                startActivity(new Intent(SalahActivityDua.this,SalahBetSujActivity.class));

                break;



            case R.id.tvSalTha :

                startActivity(new Intent(SalahActivityDua.this,SalahThashActivity.class));

                break;



            case R.id.tvSalAft :

                startActivity(new Intent(SalahActivityDua.this,SalahDuaAftActivity.class));

                break;



            case R.id.tvSalMy :

                startActivity(new Intent(SalahActivityDua.this,SalahMayyatActivity.class));

                break;





        }





    }
}
