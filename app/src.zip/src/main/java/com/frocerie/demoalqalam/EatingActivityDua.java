package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class EatingActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tveatBefo,tvEatForg,tvEatFood,tvEatMilk,tvEatAfter,tvEatHost,tvEatDrink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eating_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tveatBefo = (TextView) findViewById(R.id.tveatBefo);
        tveatBefo.setOnClickListener(EatingActivityDua.this);


        tvEatForg = (TextView) findViewById(R.id.tvEatForg);
        tvEatForg.setOnClickListener(EatingActivityDua.this);

        tvEatFood = (TextView) findViewById(R.id.tvEatFood);
        tvEatFood.setOnClickListener(EatingActivityDua.this);

        tvEatMilk = (TextView) findViewById(R.id.tvEatMilk);
        tvEatMilk.setOnClickListener(EatingActivityDua.this);

        tvEatAfter= (TextView) findViewById(R.id.tvEatAfter);
        tvEatAfter.setOnClickListener(EatingActivityDua.this);

        tvEatHost= (TextView) findViewById(R.id.tvEatHost);
        tvEatHost.setOnClickListener(EatingActivityDua.this);

        tvEatDrink= (TextView) findViewById(R.id.tvEatDrink);
        tvEatDrink.setOnClickListener(EatingActivityDua.this);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(EatingActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {


        switch (view.getId()){

            case R.id.tveatBefo :
                 startActivity(new Intent(EatingActivityDua.this,EatingBeforeActivity.class));
                break;

            case R.id.tvEatForg :
                startActivity(new Intent(EatingActivityDua.this,EatingForgetActivity.class));

                break;


            case R.id.tvEatFood :
                startActivity(new Intent(EatingActivityDua.this,EatingFoddActivity.class));
                break;

            case R.id.tvEatMilk:
                startActivity(new Intent(EatingActivityDua.this,EatingMilkActivity.class));
                break;

            case R.id.tvEatAfter:

                startActivity(new Intent(EatingActivityDua.this,EatingAfterActivity.class));
                break;

            case R.id.tvEatHost:
                startActivity(new Intent(EatingActivityDua.this,EatingHostActivity.class));
                break;


            case R.id.tvEatDrink:
                startActivity(new Intent(EatingActivityDua.this,EatingDrinrActivity.class));
                break;





        }

    }
}
