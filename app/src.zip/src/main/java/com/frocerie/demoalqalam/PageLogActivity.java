package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;

public class PageLogActivity extends AppCompatActivity implements View.OnClickListener {

    ViewPager viewPager;
    ImageView notice,plan,exam,material,topper,transport;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_log);

        initUi();



        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new MyTimerTask(),2000,4000);


        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);




    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();



        if(id == R.id.home){

            NavUtils.navigateUpFromSameTask(this);

        }

        return super.onOptionsItemSelected(item);
    }

    private void initUi() {

        viewPager = (ViewPager)findViewById(R.id.viewPage);

        notice = ( ImageView) findViewById(R.id.notice);
        notice.setOnClickListener(this);


        plan = ( ImageView) findViewById(R.id.plan);
        plan.setOnClickListener(this);


        exam = (ImageView) findViewById(R.id.hut);
        exam.setOnClickListener(this);

        material = ( ImageView) findViewById(R.id.material);
        material.setOnClickListener(this);

        topper = ( ImageView) findViewById(R.id.topper);
        topper.setOnClickListener(this);


        transport= ( ImageView) findViewById(R.id.transport);
        transport.setOnClickListener(this);



        ViewPageAdapter viewPageAdapter = new ViewPageAdapter(this);
        viewPager.setAdapter(viewPageAdapter);



    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id) {
            case R.id.notice:
                startActivity(new Intent(PageLogActivity.this,NoticeBoardActivity.class));
                break;


            case R.id.plan:
                startActivity(new Intent(PageLogActivity.this,ListOfClassActivity.class));
                break;



            case R.id.hut:
                startActivity(new Intent(PageLogActivity.this,ExamHutActivity.class));
                break;

            case R.id.material:
                startActivity(new Intent(PageLogActivity.this,MaterialsActivity.class));
                break;


            case R.id.topper:
                startActivity(new Intent(PageLogActivity.this,ToppersActivity.class));
                break;




            case R.id.transport:
                //fetchingPdf();
                
                startActivity(new Intent(PageLogActivity.this,TransporterActivity.class));
                break;







        }
    }

    //private void fetchingPdf() {

    //}


    public  class MyTimerTask extends TimerTask {




        @Override
        public void run() {


            PageLogActivity.this.runOnUiThread(new Runnable(){

                @Override
                public void run() {


                    if(viewPager.getCurrentItem()== 0) {

                        viewPager.setCurrentItem(1);

                    }else if(viewPager.getCurrentItem()==1){

                        viewPager.setCurrentItem(2);

                    }else

                        viewPager.setCurrentItem(0);
                }

            });





        }
    }
}
