package com.frocerie.demoalqalam;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentTalensDay extends Fragment implements View.OnClickListener {

    View view;
      Button  nasheed,qeerath,speech,craft,writting,sports;


    public FragmentTalensDay() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



        // Inflate the layout for this fragment
      view = inflater.inflate(R.layout.fragment_talens_day, container, false);

        init();

        return  view;
    }

    private void init() {


        nasheed = (Button) view.findViewById(R.id.nasheed);
        nasheed.setOnClickListener(FragmentTalensDay.this);

        qeerath = (Button) view.findViewById(R.id.qeerath);
        qeerath.setOnClickListener(FragmentTalensDay.this);

        speech = (Button) view.findViewById(R.id.speech);
        speech.setOnClickListener(FragmentTalensDay.this);

        craft = (Button) view.findViewById(R.id.craft);
        craft.setOnClickListener(FragmentTalensDay.this);

        writting = (Button) view.findViewById(R.id.writting);
        writting.setOnClickListener(FragmentTalensDay.this);

        sports = (Button) view.findViewById(R.id.sports);
        sports.setOnClickListener(FragmentTalensDay.this);





    }

    @Override
    public void onClick(View view) {

        int id = view.getId();

        switch (id){


            case R.id.nasheed :

                startActivity(new Intent(getActivity(),NasheedTaleActivity.class));

                break;


            case R.id.qeerath :

                //Toast.makeText(getActivity(),"Next Activity pdf file Fetch from server",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(getActivity(),QeerathTaleActivity.class));

                break;

            case R.id.speech :
                //Toast.makeText(getActivity(),"Next Activity pdf file Fetch from server",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(getActivity(),SpeechTaleActivity.class));

                break;


            case R.id.craft :
                //Toast.makeText(getActivity(),"Next Activity pdf file Fetch from server",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(getActivity(),CraftTaleActivity.class));

                break;

            case R.id.writting :
                //Toast.makeText(getActivity(),"Next Activity pdf file Fetch from server",Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getActivity(),WritingTaleActivity.class));

                break;

            case R.id.sports :
                //Toast.makeText(getActivity(),"Next Activity pdf file Fetch from server",Toast.LENGTH_SHORT).show();

                startActivity(new Intent(getActivity(),SportsTaleActivity.class));

                break;






        }





    }
}
