package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class GroomActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvGroom,tvGroomIn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_groom);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvGroom = (TextView) findViewById(R.id.tvGroom);
        tvGroom.setOnClickListener(GroomActivity.this);


        tvGroomIn = (TextView) findViewById(R.id.tvGroomIn);
        tvGroomIn.setOnClickListener(GroomActivity.this);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(GroomActivity.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvGroom :

                startActivity(new Intent(GroomActivity.this,GrromDActivity.class));
            break;

            case R.id.tvGroomIn :
                startActivity(new Intent(GroomActivity.this,GroomInActivity.class));

                break;



        }




    }
}
