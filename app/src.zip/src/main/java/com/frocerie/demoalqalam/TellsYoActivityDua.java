package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class TellsYoActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tvLov,tvForg,tvBles;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tells_yo_dua);


        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tvLov = (TextView) findViewById(R.id.tvLov);
        tvLov.setOnClickListener(TellsYoActivityDua.this);


        tvForg = (TextView) findViewById(R.id.tvForg);
        tvForg.setOnClickListener(TellsYoActivityDua.this);

        tvBles = (TextView) findViewById(R.id.tvBles);
        tvBles.setOnClickListener(TellsYoActivityDua.this);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(TellsYoActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvLov :

                startActivity(new Intent(TellsYoActivityDua.this,TellsLoveActivity.class));

                break;


            case R.id.tvForg :

                startActivity(new Intent(TellsYoActivityDua.this,TellsForgiveActivity.class));

                break;


            case R.id. tvBles :

                startActivity(new Intent(TellsYoActivityDua.this,TellsBlessActivity.class));

                break;




        }



    }
}
