package com.frocerie.demoalqalam;

import android.os.Bundle;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

public class GallYouTubeActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {



    private static final int RECOVERY_REQUEST = 1;
    private YouTubePlayerView youTubevie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gall_you_tube);

        



        youTubevie = (YouTubePlayerView) findViewById(R.id.youtube_view);

        youTubevie.initialize(PlayerConfig.API_KEY,GallYouTubeActivity.this);
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {

        if(!b){

            youTubePlayer.cueVideo("POvG2jlDBPA");

        }

    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult errorReason) {

        if(errorReason.isUserRecoverableError()){

            errorReason.getErrorDialog(GallYouTubeActivity.this,RECOVERY_REQUEST).show();

        }else{

            //String error = String.format(getString(R.string.player_error),errorReason.toString());
            //Toast.makeText(Main2Activity.this,error,Toast.LENGTH_SHORT).show();

        }

    }
}
