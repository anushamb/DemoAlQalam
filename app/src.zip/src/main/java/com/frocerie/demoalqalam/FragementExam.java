package com.frocerie.demoalqalam;


import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragementExam extends Fragment implements View.OnClickListener {

    Button first,second,third;

    View view;


    public FragementExam() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view = inflater.inflate(R.layout.fragment_exam, container, false);
        intialize();

        return  view;
    }

    private void intialize() {

        first = (Button) view.findViewById(R.id.first);
        first.setOnClickListener(FragementExam.this);

        second  = (Button) view.findViewById(R.id.second);
        second.setOnClickListener(FragementExam.this);

        third = (Button) view.findViewById(R.id.third);
        third.setOnClickListener(FragementExam.this);



    }

    @Override
    public void onClick(View view) {



        int id = view.getId();

        switch (id) {

            case R.id.first :

                startActivity(new Intent(getActivity(),ListOfRankActivity.class));
                break;


            case R.id.second :

                startActivity(new Intent(getActivity(),ListOfRankActivity.class));
                break;


            case R.id.third :

                startActivity(new Intent(getActivity(),ListOfRankActivity.class));
                break;






        }



    }
}
