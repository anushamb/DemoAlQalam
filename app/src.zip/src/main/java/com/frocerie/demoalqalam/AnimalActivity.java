package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class AnimalActivity extends AppCompatActivity implements View.OnClickListener {

    TextView tvC,tvD,tvS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);



        tvC = (TextView) findViewById(R.id.tvCrow);
        tvC.setOnClickListener(AnimalActivity.this);

        tvD = (TextView) findViewById(R.id.tvDog);
        tvD.setOnClickListener(AnimalActivity.this);

        tvS = (TextView) findViewById(R.id.tvSay);
        tvS.setOnClickListener(AnimalActivity.this);


    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){


            case R.id.tvCrow :

            startActivity(new Intent(AnimalActivity.this,CockActivity.class));
            break;

            case R.id.tvDog :

                startActivity(new Intent(AnimalActivity.this,DogActivity.class));
                break;

            case R.id.tvSay :
                startActivity(new Intent(AnimalActivity.this,SayActivity.class));
                break;


        }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(AnimalActivity.this);

        }




        return super.onOptionsItemSelected(item);
    }
}
