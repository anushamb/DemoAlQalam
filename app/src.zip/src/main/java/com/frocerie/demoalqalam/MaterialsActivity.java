package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

public class MaterialsActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView logo;

    ImageButton quran,inter,hadeesh,nasheed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materials);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        intit();
    }

    private void intit() {

        logo = (ImageView) findViewById(R.id.logo);

        quran = (ImageButton) findViewById(R.id.ivQuran);
        quran.setOnClickListener(MaterialsActivity.this);

        inter = (ImageButton) findViewById(R.id.inter);
        inter.setOnClickListener(MaterialsActivity.this);

        hadeesh = (ImageButton) findViewById(R.id.hadees);
        hadeesh.setOnClickListener(MaterialsActivity.this);

        nasheed = (ImageButton) findViewById(R.id.nasheed);
        nasheed.setOnClickListener(MaterialsActivity.this);


    }

    @Override
    public void onClick(View view) {

        int id = view.getId();

        switch (id){

            case R.id.ivQuran:

                Toast.makeText(MaterialsActivity.this,"Get Mp3 files",Toast.LENGTH_SHORT).show();
            break;


            case R.id.inter :

                Toast.makeText(MaterialsActivity.this,"Get .chm file",Toast.LENGTH_SHORT).show();
                break;

            case R.id.hadees :

                startActivity(new Intent(MaterialsActivity.this,MateriHadeesActivity.class));
               break;

            case R.id.nasheed :

                startActivity(new Intent(MaterialsActivity.this,VideoAudioActivity.class));

                break;

        }

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();



        if(id == R.id.home){

            NavUtils.navigateUpFromSameTask(MaterialsActivity.this);

        }

        return super.onOptionsItemSelected(item);
    }
}
