package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MoneyActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tvMoneyDe,tvMoneyoff,tvMoneysm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_money_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvMoneyDe = (TextView) findViewById(R.id.tvMoneyDe);
        tvMoneyDe.setOnClickListener(MoneyActivityDua.this);


        tvMoneyoff = (TextView) findViewById(R.id.tvMoneyoff);
        tvMoneyoff.setOnClickListener(MoneyActivityDua.this);



        tvMoneysm = (TextView) findViewById(R.id.tvMoneysm);
        tvMoneysm.setOnClickListener(MoneyActivityDua.this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(MoneyActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){


            case R.id.tvMoneyDe :

                startActivity(new Intent(MoneyActivityDua.this,MoneyDebtActivity.class));
                break;

            case R.id.tvMoneyoff :

                startActivity(new Intent(MoneyActivityDua.this,MoneyOfferstActivity.class));
                break;

            case R.id.tvMoneysm :

                startActivity(new Intent(MoneyActivityDua.this,MoneySomeoneActivity.class));
                break;
        }






    }
}
