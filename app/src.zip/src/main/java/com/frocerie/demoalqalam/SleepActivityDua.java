package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class SleepActivityDua extends AppCompatActivity implements View.OnClickListener {


    TextView tvSleeBef,tvSleeWake,tvSleeNight,tvSleeDepr,tvSleenightm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sleep_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvSleeBef = (TextView) findViewById(R.id.tvSleeBef);
        tvSleeBef.setOnClickListener(SleepActivityDua.this);


        tvSleeWake = (TextView) findViewById(R.id.tvSleeWake);
        tvSleeWake.setOnClickListener(SleepActivityDua.this);


        tvSleeNight = (TextView) findViewById(R.id.tvSleeNight);
        tvSleeNight.setOnClickListener(SleepActivityDua.this);


        tvSleeDepr = (TextView) findViewById(R.id.tvSleeDepr);
        tvSleeDepr.setOnClickListener(SleepActivityDua.this);

        tvSleenightm = (TextView) findViewById(R.id.tvSleenightm);
        tvSleenightm.setOnClickListener(SleepActivityDua.this);







    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(SleepActivityDua.this);

        }




        return super.onOptionsItemSelected(item);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){



            case R.id. tvSleeBef :

                startActivity(new Intent(SleepActivityDua.this,SleepBeforeActvity.class));
                break;



            case R.id.tvSleeWake :

                startActivity(new Intent(SleepActivityDua.this,SleepWakeActvity.class));
                break;



            case R.id.tvSleeNight :

                startActivity(new Intent(SleepActivityDua.this,SleepNightActvity.class));
                break;



            case R.id.tvSleeDepr :

                startActivity(new Intent(SleepActivityDua.this,SleepDeprActvity.class));
                break;



            case R.id.tvSleenightm :

                startActivity(new Intent(SleepActivityDua.this,SleepNightmareActvity.class));
                break;



        }

    }
}
