package com.frocerie.demoalqalam;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by avocet on 12/06/17.
 */

public class SpeechInfoAdapter extends RecyclerView.Adapter<SpeechInfoAdapter.ViewHolder> {


    private List<ListSpeechInfoItemModel> listItem;
    private Context context;


    public  SpeechInfoAdapter(List<ListSpeechInfoItemModel> listItem, Context context){


       this.listItem = listItem;
        this.context = context;



    }


    @Override
    public SpeechInfoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.speech_item,parent,false);

        return  new ViewHolder(v);


    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        //to get the specific position of the listItem
        final ListSpeechInfoItemModel listItemModel = listItem.get(position);

        //setting the header and description to the TextView
        holder.textViewHead.setText(listItemModel.getHead());
        holder.textViewDesc.setText(listItemModel.getDesc());

        //To load image we are using Picasso library file
        Picasso.with(context)
                .load(listItemModel.getImageUrl())
                .into(holder.imageView);

        //code for clicking the lineralayout

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Toast.makeText(context,"You clicked" + listItemModel.getHead(),Toast.LENGTH_LONG).show();

            }
        });


    }

    @Override
    public int getItemCount() {
        //return the size of the list

        return listItem.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{


        public TextView textViewHead;
        public TextView textViewDesc;
        public ImageView imageView;
        public LinearLayout linearLayout;




        public ViewHolder(View itemView) {
            super(itemView);

            textViewHead = (TextView) itemView.findViewById(R.id.textViewHead);
            textViewDesc = (TextView) itemView.findViewById(R.id.textViewDesc);
            imageView = (ImageView) itemView.findViewById(R.id.imageView);

            linearLayout = (LinearLayout) itemView.findViewById(R.id.linearLayout);


        }
    }






}
