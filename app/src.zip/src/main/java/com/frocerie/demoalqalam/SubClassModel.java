package com.frocerie.demoalqalam;

/**
 * Created by avocet on 28/06/17.
 */

public class SubClassModel {

    private String subClass;

    private String id;

    public SubClassModel(String subClass,String id) {

        this.subClass = subClass;
        this.id = id;
    }

    public String getSubClass() {
        return subClass;
    }
}
