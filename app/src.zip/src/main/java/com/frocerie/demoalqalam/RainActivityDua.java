package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import static android.R.attr.id;

public class RainActivityDua extends AppCompatActivity implements View.OnClickListener {


    TextView tvrainblow,tvRainThun,tvRainFor,tvRainWhen,tvRainAfter,tvRainWith;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rain_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvrainblow = (TextView) findViewById(R.id.tvrainblow);
        tvrainblow.setOnClickListener(RainActivityDua.this);

        tvRainThun = (TextView) findViewById(R.id.tvRainThun);
        tvRainThun.setOnClickListener(RainActivityDua.this);

        tvRainFor = (TextView) findViewById(R.id.tvRainFor);
        tvRainFor.setOnClickListener(RainActivityDua.this);

        tvRainAfter = (TextView) findViewById(R.id.tvRainAfter);
        tvRainAfter.setOnClickListener(RainActivityDua.this);

        tvRainWhen = (TextView) findViewById(R.id.tvRainWhen);
        tvRainWhen.setOnClickListener(RainActivityDua.this);

        tvRainWith = (TextView) findViewById(R.id.tvRainWith);
        tvRainWith.setOnClickListener(RainActivityDua.this);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(RainActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {


        switch (view.getId()){



            case R.id. tvrainblow :
            startActivity(new Intent(RainActivityDua.this,RainBlowActivity.class));
            break;



            case R.id. tvRainThun :
                startActivity(new Intent(RainActivityDua.this,RainThunderActivity.class));
                break;


            case R.id.tvRainFor :
                startActivity(new Intent(RainActivityDua.this,RainForActivity.class));
                break;

            case R.id.tvRainWhen :
                startActivity(new Intent(RainActivityDua.this,RainWhenActivity.class));
                break;



            case R.id.tvRainAfter :
                startActivity(new Intent(RainActivityDua.this,RainAfterActivity.class));
                break;




            case R.id.tvRainWith :
                startActivity(new Intent(RainActivityDua.this,RainWithhoActivity.class));
                break;



        }


    }
}
