package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class EnteringActivityDua extends AppCompatActivity implements View.OnClickListener {

  TextView  tvEnterT,tvLevT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entering_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvEnterT = (TextView) findViewById(R.id.tvEnterT);
        tvEnterT.setOnClickListener(EnteringActivityDua.this);

        tvLevT = (TextView) findViewById(R.id.tvLevT);
        tvLevT.setOnClickListener(EnteringActivityDua.this);




    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(EnteringActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){


            case R.id.tvEnterT :

                startActivity(new Intent(EnteringActivityDua.this,EnteringToActivity.class));

                break;

            case R.id.tvLevT :
                startActivity(new Intent(EnteringActivityDua.this,LeavingToAvtivity.class));

              break;



        }
    }
}
