package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class AssemblyActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tvSit,tvExpi;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assembly_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvSit = (TextView) findViewById(R.id.tvSitti);
        tvSit.setOnClickListener(AssemblyActivityDua.this);

        tvExpi = (TextView) findViewById(R.id.tvExpi);
        tvExpi.setOnClickListener(AssemblyActivityDua.this);



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(AssemblyActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvSitti :
                startActivity(new Intent(AssemblyActivityDua.this,SittingAcctivity.class));
                break;

            case R.id.tvExpi :

                startActivity(new Intent(AssemblyActivityDua.this,ExpiationActivity.class));


        }








    }
}
