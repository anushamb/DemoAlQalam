package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class MasqueActivityDua extends AppCompatActivity implements View.OnClickListener {


    TextView tvMasjidGoi,tvMasjidEnt,tvMasjidLev;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_masque_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvMasjidGoi = (TextView) findViewById(R.id.tvMasjidGoi);
        tvMasjidGoi.setOnClickListener(MasqueActivityDua.this);

        tvMasjidEnt = (TextView) findViewById(R.id.tvMasjidEnt);
        tvMasjidEnt.setOnClickListener(MasqueActivityDua.this);


        tvMasjidLev = (TextView) findViewById(R.id.tvMasjidLev);
        tvMasjidLev.setOnClickListener(MasqueActivityDua.this);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(MasqueActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvMasjidGoi :

                startActivity(new Intent(MasqueActivityDua.this,MasqueGoingActivity.class));
                break;


            case R.id.tvMasjidEnt:

                startActivity(new Intent(MasqueActivityDua.this,MasqueEnterActivity.class));
                break;




            case R.id.tvMasjidLev :

               startActivity(new Intent(MasqueActivityDua.this,MasqueLevActivity.class));
                break;



        }



    }
}
