package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class CongraulationsActivityDua extends AppCompatActivity implements View.OnClickListener {


       TextView tvConNew,tvConReply;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_congraulations_dua);


        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tvConNew = (TextView) findViewById(R.id.tvConNew);
        tvConNew.setOnClickListener(CongraulationsActivityDua.this);

        tvConReply = (TextView) findViewById(R.id.tvConReply);
        tvConReply.setOnClickListener(CongraulationsActivityDua.this);





    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvConNew :

                startActivity(new Intent(CongraulationsActivityDua.this,CongNewActivity.class));
                break;


            case R.id.tvConReply :

                startActivity(new Intent(CongraulationsActivityDua.this,CongPutActivity.class));
                break;




        }




    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(CongraulationsActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }
}
