package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import java.util.Timer;
import java.util.TimerTask;



public class FrontPage extends AppCompatActivity implements View.OnClickListener, View.OnTouchListener {

    ViewPager viewPager;
    ImageView dua, time, gall, speech, batch, about;



   /* static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    static final int CLICK = 3;
    Matrix matrix = new Matrix();
    int mode = NONE;
    // Remember some things for zooming
    PointF last = new PointF();
    PointF start = new PointF();
    float minScale = 1f;
    float maxScale = 3f;
    float[] m;
    float redundantXSpace, redundantYSpace;
    float width, height;
    float saveScale = 1f;
    float right, bottom, origWidth, origHeight, bmWidth, bmHeight;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_front_page);
        initUi();

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new MyTimerTask(), 4000, 4000);

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        switch (id){

            case R.id.loginIcon :

                startActivity(new Intent(this,LoginActivity.class));

                break;

            case R.id.share :

                //Toast.makeText(this,"Cose to share option",Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(Intent.ACTION_SEND);
                myIntent.setType("text/plan");
                String shareBody = "Your body here";
                String shareSub = "TYour Subject here";
                myIntent.putExtra(Intent.EXTRA_SUBJECT,shareBody);
                myIntent.putExtra(Intent.EXTRA_TEXT,shareSub);
                startActivity(Intent.createChooser(myIntent,"Share Using"));

                break;

        }


        //if(id==R.id.loginIcon){

           //startActivity(new Intent(this,LoginActivity.class));


       // }

        return super.onOptionsItemSelected(item);
    }




    private void initUi() {


        viewPager = (ViewPager) findViewById(R.id.viewPager);


        ViewPageAdapter viewPageAdapter = new ViewPageAdapter(this);
        viewPager.setAdapter(viewPageAdapter);
        viewPager.setOnTouchListener(FrontPage.this);






        dua = (ImageView) findViewById(R.id.dua);
        dua.setOnClickListener(this);

        time = (ImageView) findViewById(R.id.time);
        time.setOnClickListener(this);

        gall = (ImageView) findViewById(R.id.gall);
        gall.setOnClickListener(this);

        speech = (ImageView) findViewById(R.id.speech);
        speech.setOnClickListener(this);

        batch = (ImageView) findViewById(R.id.batch);
        batch.setOnClickListener(this);

        about = (ImageView) findViewById(R.id.about);
        about.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        int id = view.getId();
        switch (id) {
            case R.id.dua:

                startActivity(new Intent(this,ListOfDua.class));
                break;


            case R.id.time:
                startActivity(new Intent(this,ListOfMonths.class));
                break;


            case R.id.gall:
                startActivity(new Intent(this,GallYouTubeActivity.class));
                break;


            case R.id.speech:
                startActivity(new Intent(this,SpechInfoActivity.class));
                break;

            case R.id.batch:
                startActivity(new Intent(this,BatchActivity.class));
                break;


            case R.id.about:
                startActivity(new Intent(this,AboutEx.class));
                break;


        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {

        return true;


        //return false;
    }

    public class MyTimerTask extends TimerTask {





        @Override
        public void run() {


            FrontPage.this.runOnUiThread(new Runnable() {

                @Override
                public void run() {


                    if (viewPager.getCurrentItem() == 0) {

                        viewPager.setCurrentItem(1);

                    } else if (viewPager.getCurrentItem() == 1) {

                        viewPager.setCurrentItem(2);

                    } else if (viewPager.getCurrentItem() == 2) {

                        viewPager.setCurrentItem(3);

                    } else if (viewPager.getCurrentItem() == 3) {

                        viewPager.setCurrentItem(4);

                    } else {

                            viewPager.setCurrentItem(0);

                    }




                }

            });


        }
    }


}