package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class AllahDuaActivity extends AppCompatActivity implements View.OnClickListener {

      TextView tvRem,tvSeek;

      TextView tvExce,tvExcelRem,tvProphet;

        Intent intent;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allah_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        initi();

    }

    private void initi() {

        tvRem = (TextView) findViewById(R.id.tvRem);
        tvRem.setOnClickListener(AllahDuaActivity.this);

        tvSeek = (TextView) findViewById(R.id.tvSeek);
        tvSeek.setOnClickListener(AllahDuaActivity.this);


        tvExce = (TextView) findViewById(R.id.tvExce);
        tvExce.setOnClickListener(AllahDuaActivity.this);

        tvExcelRem = (TextView)findViewById(R.id.tvExcelRem);
        tvExcelRem.setOnClickListener(AllahDuaActivity.this);

        tvProphet = (TextView) findViewById(R.id.tvProphet);
        tvProphet.setOnClickListener(AllahDuaActivity.this);


    }

    @Override
    public void onClick(View view) {

          switch (view.getId()){

              case R.id.tvRem :

                  intent = new Intent(AllahDuaActivity.this,RemembranceActivity.class);
                  startActivity(intent);
                  break;

              case R.id.tvSeek :
                  intent = new Intent(AllahDuaActivity.this,SeekActivity.class);
                  startActivity(intent);
                  //Toast.makeText(AllahDuaActivity.this,"Connect to another activity",Toast.LENGTH_SHORT).show();
                 break;

              case R.id.tvExce :
                  intent = new Intent(AllahDuaActivity.this,ExcellenceActivity.class);
                  startActivity(intent);

                  //Toast.makeText(AllahDuaActivity.this,"Connect to another activity",Toast.LENGTH_SHORT).show();
                  break;

              case R.id.tvExcelRem :

                  intent = new Intent(AllahDuaActivity.this,ExcellenceRemebActivity.class);
                  startActivity(intent);
                  //Toast.makeText(AllahDuaActivity.this,"Connect to another activity",Toast.LENGTH_SHORT).show();
                  break;

              case R.id.tvProphet :

                  intent = new Intent(AllahDuaActivity.this,ProphetActivity.class);
                  startActivity(intent);
                  //Toast.makeText(AllahDuaActivity.this,"Connect to another activity",Toast.LENGTH_SHORT).show();
                  break;






          }


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(AllahDuaActivity.this);

        }




        return super.onOptionsItemSelected(item);
    }
}
