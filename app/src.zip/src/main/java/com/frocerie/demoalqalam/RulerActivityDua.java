package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

public class RulerActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tvRuMeet,tvRuAgai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ruler_dua);


        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tvRuMeet = (TextView) findViewById(R.id.tvRuMeet);
        tvRuMeet.setOnClickListener(RulerActivityDua.this);


        tvRuAgai = (TextView) findViewById(R.id.tvRuAgai);
        tvRuAgai.setOnClickListener(RulerActivityDua.this);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(RulerActivityDua.this);

        }




        return super.onOptionsItemSelected(item);




    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.tvRuMeet :

                startActivity(new Intent(RulerActivityDua.this,RulerWhenActvity.class));

                break;

            case R.id.tvRuAgai :
                startActivity(new Intent(RulerActivityDua.this,RulerAgainstActivity.class));

                break;




        }



    }
}
