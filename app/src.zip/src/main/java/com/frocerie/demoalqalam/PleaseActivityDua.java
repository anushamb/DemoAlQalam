package com.frocerie.demoalqalam;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;


public class PleaseActivityDua extends AppCompatActivity implements View.OnClickListener {

    TextView tvPleSm,tvPleDis,tvPleHapp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_please_dua);

        getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        tvPleSm = (TextView) findViewById(R.id.tvPleSm);
        tvPleSm.setOnClickListener(PleaseActivityDua.this);

        tvPleDis = (TextView) findViewById(R.id.tvPleDis);
        tvPleDis.setOnClickListener(PleaseActivityDua.this);

        tvPleHapp  = (TextView) findViewById(R.id.tvPleHapp);
        tvPleHapp.setOnClickListener(PleaseActivityDua.this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int i = item.getItemId();
        if(i == R.id.home){


            NavUtils.navigateUpFromSameTask(PleaseActivityDua.this);

        }




        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){


            case R.id.tvPleSm :

                startActivity(new Intent(PleaseActivityDua.this,PleaseSomActivity.class));

                break;

            case R.id.tvPleDis :

                startActivity(new Intent(PleaseActivityDua.this,PleaseDisplActivity.class));

                break;

            case R.id. tvPleHapp:

                startActivity(new Intent(PleaseActivityDua.this,PleaseHappeActivity.class));

                break;



        }




    }
}
