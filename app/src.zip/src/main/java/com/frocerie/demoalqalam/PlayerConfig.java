package com.frocerie.demoalqalam;

/**
 * Created by avocet on 22/06/17.
 */

public class PlayerConfig {

    PlayerConfig(){



    }


    public  static  final String API_KEY = "AIzaSyDTaP8Wpf7wQLipJkWeJtE0EbikXLmwVew";
}
